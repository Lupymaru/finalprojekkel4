﻿using System;

namespace AbsensiAppMVC.View
{
    internal interface IFrmMahasiswa
    {
        EventHandler FrmMahasiswa_Load { get; }
    }
}